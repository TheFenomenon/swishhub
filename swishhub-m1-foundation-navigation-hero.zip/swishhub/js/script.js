// ==========================================================================
// SWISSHUB INTERACTIVE: script.js
// Currently only handles the mobile navigation toggle.
// ==========================================================================

// 1. Find the three elements we need.
const header = document.querySelector(".site-header");
const menuButton = document.querySelector(".site-nav-toggle");
const siteNav = document.getElementById("site-nav");

// 2. Only continue if all three exist. On a page without them,
//    the script quietly does nothing instead of throwing an error.
if (header && menuButton && siteNav) {

  // Tell the CSS that JavaScript is working. This reveals the Menu button
  // and collapses the links on small screens.
  header.classList.add("site-header--js");

  // 3. When the button is activated (tap, click, Enter or Space),
  //    flip aria-expanded between "true" and "false".
  //    The CSS reads that attribute and shows or hides the links.
  menuButton.addEventListener("click", function () {
    const isOpen = menuButton.getAttribute("aria-expanded") === "true";
    menuButton.setAttribute("aria-expanded", String(!isOpen));
  });
}
